<?php
$nama = 'localhost';
$user = 'root';
$pw = '';
$db = 'db_pelanggaran';

$mysqli = mysqli_connect($nama, $user, $pw, $db);