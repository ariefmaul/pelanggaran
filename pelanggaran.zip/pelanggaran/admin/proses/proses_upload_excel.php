<?php
include '../../cofig.php'
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['excelFile'])) {
    $file = $_FILES['excelFile']['tmp_name'];
    $spreadsheet = IOFactory::load($file);
    $worksheet = $spreadsheet->getActiveSheet();

    // Validasi header Excel
    $expectedHeaders = ['nis', 'nisn', 'nama_lengkap', 'kelas']; 
    $actualHeaders = $worksheet->rangeToArray('A1:' . $worksheet->getHighestColumn() . '1', null, true, false, true)[0];

    if ($expectedHeaders !== $actualHeaders) {
        echo "Format file Excel tidak sesuai.";
        exit;
    }

    // Proses data dan insert ke database
    $highestRow = $worksheet->getHighestRow();
    for ($row = 2; $row <= $highestRow; $row++) {
        $nis = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
        $nisn = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
        $nama = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
        $kelas = $worksheet->getCellByColumnAndRow(4, $row)->getValue();

        $sql = "INSERT INTO siswa (nis, nisn, nama_lengkap, kelas) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $nis, $nisn, $nama, $kelas);
        $stmt->execute();
    }

    echo "Upload dan import data berhasil.";
}
?>