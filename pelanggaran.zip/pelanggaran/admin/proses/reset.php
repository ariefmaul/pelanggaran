<?php
include("../../cofig.php");
$hapuschart = $mysqli->query("UPDATE `tbl_pelanggaran` SET `id_pelanggara`='1',`waktu`= 0,`sepatu`= 0,`kaos_kaki`= 0,`pakian`= 0,`sabuk`= 0,`make_up`= 0,`kesiangan`= 0,`dasi`= 0,`skoder`= 0 WHERE 1");
$hapus_pelanggaran = $mysqli->query("DELETE FROM `pelanggaran`");
$hapuskesiangan = $mysqli->query("UPDATE `siswa` SET `jumlah`= 0 ");

header('location: ../admin.php?ket=utama&status=berhasil');
?>