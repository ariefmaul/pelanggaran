<?php
include('../../cofig.php');
$nama = $_POST['nama'];
$pw = $_POST['password'];
$qData = $mysqli->query("SELECT * FROM tbl_user");
$seleksi = $mysqli->query("SELECT * FROM tbl_user WHERE `nama` = '$nama' AND `password` = '$pw'");
if ($seleksi->num_rows > 0) {
    $data = $seleksi->fetch_array();
    session_start();
    $_SESSION['ses_nama'] = $data['nama'];
    header("location: ../admin.php?ket=utama");
} else {
    header("location: ../index.php?ket=gagal");
    
}