<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Dashboard</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group me-2">

                <button type="button" onclick="window.open('convert/laporan_pelanggaran.php')"
                    class="btn btn-sm btn-outline-secondary">
                    <i class="fa-solid fa-cloud-arrow-down"></i> Export
                </button>
            </div>


        </div>
    </div>
    <div id="chart"></div>





    <h2>Data Pelanggar</h2>
    <div class="d-flex justify-content-end mb-1">

        <div class=" col-sm-12 row">

            <div class="col-sm-5 mb-1"> <input type="date" onkeydown="tampil()" placeholder="Cari Tanggal"
                    class="form-control" id="cari1">
            </div>
            <div class="col-sm-2 ">
                <button onclick="cari()" class="btn btn-primary"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>

        </div>

    </div>
    <div class="d-" id="download">

    </div>
    <div class="table-responsive small">
        <table class="table table-striped table-sm" id="tampil">

        </table>
    </div>
    <p class="mt-5 mb-3 text-body-secondary text-center">&copy; Copyright OSIS 2024-2025</p>
</main>
<script>
window.onload = () => {
    tampil();
    chart();
    // download();
}

function tampil() {
    $("#tampil").load('load/data.php', {
        key1: $('#cari1').val(),
    }, function() {

    });

}

function download() {
    $("#tampil").load('convert/laporan_pelanggaran.php', {
        key: $('#cari1').val(),
    }, function() {

    });
}

function chart() {
    $('#chart').load('load/chart.php')
}
</script>
<script src="../../assets/js/jquery.js"></script>