<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">

        <h2>Data Siswa</h2>
    </div>





    <div class=" mb-1">

        <div class="row">
            <div class=" col-lg-6 row">

                <div class="col-sm-5 mb-1"> <input type="text" onkeydown="tampil_siswa()" placeholder="Cari Nama Siswa"
                        class="form-control" id="cari3">
                </div>
                <div class="col-sm-2 ">
                    <button onclick="cari()" class="btn btn-primary"><i
                            class="fa-solid fa-magnifying-glass"></i></button>
                </div>

            </div>
            <div class="col-lg-6 d-flex justify-content-end row">
                <!-- <div class="col-lg-9 row ">
                    <button onclick="document.getElementById('fileInput').click()" class="btn btn-primary col-lg-5"><i
                            class="fa-solid fa-plus"></i> Data Siswa</button>
                    <input type="file" id="fileInput" style="display: none;" accept=".xlsx, xls">
                    <button class="btn btn-danger ms-1 col-lg-5"><i class="fa-solid fa-trash"></i> Data
                        Siswa</button>
                </div> -->
            </div>
        </div>

    </div>
    <div class="d-" id="download">

    </div>
    <div class="table table-responsive small">
        <table class="table table-striped table-sm" id="tampil3">

        </table>
    </div>
    <p class="mt-5 mb-3 text-body-secondary text-center">&copy; Copyright OSIS 2024-2025</p>
</main>
<script>
window.onload = () => {
    tampil_siswa();
    // download();
}

function tampil_siswa() {
    $("#tampil3").load('load/siswa.php', {
        cari: $('#cari3').val(),
    }, function() {

    });

}

// function download() {
//     $("#tampil").load('convert/laporan_pelanggaran.php', {
//         key: $('#cari1').val(),
//     }, function() {

//     });
// }


//button upload function
document.getElementById('fileInput').addEventListener('change', function() {
    var file = this.file[0];
    var formData = new formData();
    formData.append('excelFile', file);

    fetch('/proses/proses_upload_excel', {
        method: 'POST',
        body: FormData
    })
    .then(response => response.text())
    .then(data => {
        document.getElementById('result').innerHTML = data;
    });
});
</script>