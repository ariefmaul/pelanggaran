<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
    <div
        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h2>Data Pelanggar</h2>

    </div>






    <div class="d-flex justify-content-end mb-1">

        <div class=" col-sm-12 row">

            <div class="col-sm-5 mb-1">
                <input type="text" onkeyup="tampil_kelas()" placeholder="Cari Kelas" class="form-control" id="cari2">
            </div>
            <div class="col-sm-2 ">
                <button onclick="cari1()" class="btn btn-primary"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>

        </div>

    </div>
    <!-- <div class="d-flex table justify-content-center row" id="tampil1">

    </div> -->
    <div class="table-responsive small">
        <table class="table table-striped table-sm" id="tampil1">

        </table>
    </div>
    <p class="mt-5 mb-3 text-body-secondary text-center">&copy; Copyright OSIS 2024-2025</p>
</main>
<script>
window.onload = () => {
    tampil_kelas();
    // download();
}

function tampil_kelas() {
    $("#tampil1").load('load/perkelas.php', {
        keyy: $('#cari2').val(),
    }, function() {

    });

}

function cari1() {
    // chart(); 
    tampil_kelas();
}

// function download() {
//     $("#tampil").load('convert/laporan_pelanggaran.php', {
//         key: $('#cari1').val(),
//     }, function() {

//     });
// }
</script>
<script src="../../assets/js/jquery.js"></script>