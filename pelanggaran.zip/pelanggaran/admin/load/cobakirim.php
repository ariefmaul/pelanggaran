<?php

$KEY = $_POST['dat'];
echo $KEY;