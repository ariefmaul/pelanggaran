<thead>
    <tr>
        <th>No</th>
        <th>Tanggal</th>
        <th>Waktu</th>
        <th>Nama</th>
        <th>Kelas</th>
        <th>Jenis Pelanggaran</th>
    </tr>
</thead>

<tbody>
    <?php
    include('../../cofig.php');
    $cari = $_POST['key1'];
    if ($cari == '') {
        $data = $mysqli->query("SELECT * FROM pelanggaran ORDER BY tanggal AND waktu DESC");
    } else {
        $data = $mysqli->query("SELECT * FROM pelanggaran WHERE tanggal = '$cari'");
    }
    if ($data->num_rows < 1) {
        echo "<td colspan='6' class='text-danger'>Data Tidak Di Temukan</td>";
    } else {
        $no = 1;
        while ($tampil = $data->fetch_array()) {
            echo '<tr>';
            echo '<td>'.$no.'</td>';
            echo'<td>'.$tampil["tanggal"].'</td>';
            echo'<td>'.$tampil["waktu"].'</td>';
            echo'<td>'.$tampil["nama"].'</td>';
            echo'<td>'.$tampil["kelas"].'</td>';
            echo'<td>'.$tampil["pelanggaran"].'</td>';
            echo '</tr>';
            $no++;
        }
    }
    
    
    ?>
</tbody>