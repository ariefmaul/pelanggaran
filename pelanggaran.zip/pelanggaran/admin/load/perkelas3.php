<?php
include '../../cofig.php';
$call = $mysqli->query("SELECT * FROM kelas");
while ($cal = $call->fetch_array()) {
    echo '
    
    <div class="card col-lg-3 m-3">
    <div class="card-header">
        '.$cal['kelas'].'
    </div>
    <div class="card-body">
        <p>'.$cal['kelas'].'</p>
        <p>Jumlah Siswa</p>

    </div>
    <div class="card-footer d-flex justify-content-end">
        <a href="'.$cal['kelas'].'" class="btn btn-primary">Join </a>
    </div>
</div>';
}
