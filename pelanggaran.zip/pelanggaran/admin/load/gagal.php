<div class="alert alert-danger alert-dismissible fade show d-" id="gagal" role="alert">
    <strong><i class="fa-solid fa-circle-xmark"></i> Username atau Pasword Salah</strong> Pastikan Username atau
    password
    benar

</div>