<thead>
    <tr>
        <th>No</th>
        <th>Tanggal</th>
        <th>Waktu</th>
        <th>Nama</th>
        <th>Kelas</th>
        <th>Jenis Pelanggaran</th>
    </tr>
</thead>

<tbody>
    <?php
    include('../../cofig.php');
    $cari1 = $_POST['keyy'];
    if ($cari1 == '') {
        $data2 = $mysqli->query("SELECT * FROM pelanggaran ORDER BY kelas DESC");
    } else {
        $data2 = $mysqli->query("SELECT * FROM pelanggaran WHERE kelas LIKE '%$cari1%'");
    }
    if ($data2->num_rows < 1) {
        echo "<td colspan='6' class='text-danger'>Data Tidak Di Temukan</td>";
    } else {
        $no = 1;
        while ($tampil2 = $data2->fetch_array()) {
            echo '<tr>';
            echo '<td>'.$no.'</td>';
            echo'<td>'.$tampil2["tanggal"].'</td>';
            echo'<td>'.$tampil2["waktu"].'</td>';
            echo'<td>'.$tampil2["nama"].'</td>';
            echo'<td>'.$tampil2["kelas"].'</td>';
            echo'<td>'.$tampil2["pelanggaran"].'</td>';
            echo '</tr>';
            $no++;
        }
    }
    
    
    ?>
</tbody>