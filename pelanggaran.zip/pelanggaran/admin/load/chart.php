<div>
    
    <canvas id="myChart"></canvas>
</div>


<script>
const ctx = document.getElementById('myChart');
<?php 
    include("../../cofig.php");
    // $cari1 = $_POST['key'];
    // if ($cari1 == '') {
        $data = $mysqli->query("SELECT * FROM tbl_pelanggaran WHERE id_pelanggara = 1");
    // } else {
    // date_default_timezone_set("Asia/Jakarta");
    // $cari1 = date('Y-m-d');
    //     $data = $mysqli->query("SELECT * FROM tbl_pelanggaran WHERE waktu = '$cari1'");
    // }
    
    // if ($data->num_rows < 1) {
    // }else {
        while ($tampil = $data->fetch_array()) {
           
        ?>
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Sepatu', 'Kaos Kaki', 'Dasi', 'Sabuk', 'Pakaian', 'Kesiangan','Skoder', 'Make Up'],
        datasets: [{
            label: 'Siswa',
            data: [<?php echo $tampil['sepatu']?>, <?php echo $tampil['kaos_kaki']?>,
                <?php echo $tampil['dasi']?>, <?php echo $tampil['sabuk']?>,
                <?php echo $tampil['pakian']?>, <?php echo $tampil['kesiangan']?>,<?php echo $tampil['skoder']?>,<?php echo $tampil['make_up']?> 
            ],
            borderWidth: 1
        }]
    },
    <?php
        // }   
}
?>
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
</script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>