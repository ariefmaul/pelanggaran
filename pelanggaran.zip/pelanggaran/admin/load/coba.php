<?php
$key = $_POST['key'];
echo $key;