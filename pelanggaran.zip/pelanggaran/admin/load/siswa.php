<thead>
    <tr>
        <th>No</th>
        <th>NIS</th>
        <th>NISN</th>
        <th>NAMA LENGKAP</th>
        <th>KELAS</th>
        <th>JUMLAH KESIANGAN</th>
    </tr>
</thead>

<tbody>
    <?php
    include('../../cofig.php');
    $cari = $_POST['cari'];
    if ($cari == '') {
        $data1 = $mysqli->query("SELECT * FROM siswa ORDER BY NIS ASC");
    } else {
        $data1 = $mysqli->query("SELECT * FROM siswa WHERE NAMA LIKE '%$cari%'");
    }
    if ($data1->num_rows < 1) {
        echo "<td colspan='6' class='text-danger'>Data Tidak Di Temukan</td>";
    } else {
        $no = 1;
        while ($tampil1 = $data1->fetch_array()) {
            echo '<tr>';
            echo '<td>'.$no.'</td>';
            echo'<td>'.$tampil1["NIS"].'</td>';
            echo'<td>'.$tampil1["NISN"].'</td>';
            echo'<td>'.$tampil1["NAMA"].'</td>';
            echo'<td>'.$tampil1["KELAS"].'</td>';
            echo'<td>'.$tampil1["jumlah"].'</td>';
            echo '</tr>';
            $no++;
        }
    }
    
    
    ?>
</tbody>