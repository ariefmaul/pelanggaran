<div class="alert alert-success alert-dismissible fade show d-" id="berhasil" role="alert">
    <strong><i class="fa-solid fa-circle-check"></i> Data Berhasil Dicatat</strong> Silahkan Berikan Bukti ini
    ke OSIS. Reload Untuk Mengisi Data Lain

</div>