<form action="proses/proseslogin.php" method="post">
<div class="form-group mb-3">
    <label for="">Username</label>
    <input type="text" class="form-control nama" id="nama" placeholder="Nama Lengkap" required name="nama" />
</div>
<div class="form-group mb-3">
    <label for="">Password</label>
    <input type="password" class="form-control" placeholder="Password" id="password" name="password">
</div>
<button class="btn btn-primary w-100 py-2" type="submit">
            Kirim <i class="fa-solid fa-paper-plane"></i>
        </button>
<div id="aksi7">
</div>
</form>