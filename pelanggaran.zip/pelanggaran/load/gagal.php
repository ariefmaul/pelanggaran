<div class="alert alert-danger alert-dismissible fade show d-" id="gagal" role="alert">
    <strong><i class="fa-solid fa-circle-xmark"></i> Data Tidak ditemukan</strong> Pastikan Nama atau Kelas
    benar

</div>