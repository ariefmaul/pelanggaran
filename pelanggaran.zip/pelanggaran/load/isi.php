<div class="alert alert-warning alert-dismissible fade show d-" id="isi" role="alert">
    <strong><i class="fa-solid fa-circle-question"></i> Isi Data!!</strong> Pastikan semuanya telah terisi dengan benar.

</div>