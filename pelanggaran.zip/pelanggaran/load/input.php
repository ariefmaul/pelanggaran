<form action="" required>
    <div class="form-group mb-3">
        <label for="">Nama Lengkap</label>
        <input type="text" class="form-control nama" id="nama" placeholder="Nama Lengkap" required />
    </div>
    <div class="form-group mb-3">
        <label for="">Kelas</label>
        <select name="" id="kelas" class="form-control kelas" required>
            <option value="">Pilih</option>
            <?php
              include("../cofig.php");
              $option = $mysqli->query("SELECT * FROM `kelas`");
              while ($data = $option->fetch_array()) {
                
                echo '<option value="'.$data['kelas'].'">'.$data['kelas'].'</option>';
              }
          ?>
        </select>
    </div>
    <div class="form-group mb-3">
        <label for="">Pelanggaran</label>
        <select class="form-control pelanggaran" id='pelanggaran'>
            <option value="">Pilih</option>
            <option value="Kaos Kaki">Kaos Kaki</option>
            <option value="Sepatu">Sepatu</option>
            <option value="Skoder">Skoder</option>
            <option value="Dasi">Dasi</option>
            <option value="Pakaian">Pakaian</option>
            <option value="Sabuk">Sabuk</option>
            <option value="Kesiangan">Kesiangan</option>
            <option value="Make Up">Make Up</option>
        </select>
    </div>
</form>

<script>
function simpan() {
    var data = {
        nama: $("#nama").val(),
        kelas: $("#kelas").find(":selected").val(),

    };

    if ($('.pelanggaran').val() === "") {
        // loadinfo();
        // alert('isi dengan benar')
        loadisi();
        if ($('#nama').val() == '') {
            $('.nama').addClass("border-danger");
        } else {
            $('.nama').addClass("border-success");
        }
        if ($('#kelas').val() == '') {
            $('.kelas').addClass("border-danger");
        } else {
            $('.kelas').addClass("border-success");
        }
        if ($('#pelanggaran').find(':selected').val() == '') {
            $('.pelanggaran').addClass("border-danger");
        } else {
            $('.pelanggaran').addClass("border-success");
        }

    } else {
        $(this).addClass("border-success");
        $("#aksi").load("proses/seleksi.php", data, function(isi) {

            if (isi == "gagal") {

                loadgagal();

            }
        });
        $("#aksi").load("proses/seleksi.php", data, function(isi) {
            if (isi == "berhasil") {
                insert();
                loadinput();

            } else {
                // loadinfo();

            }
        });
    };

}
</script>