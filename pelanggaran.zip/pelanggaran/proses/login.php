<?php

include("../cofig.php");
$nama = $_POST['user'];
$pass = $_POST['pas'];
$selek = $mysqli->query("SELECT * FROM `tbl_user` WHERE `nama` = '$nama' AND `password` = '$pass' ");
if ($selek->num_rows > 0) {
   echo 'berhasil';
} else {
    echo'gagal';
}