<?php
include ("../cofig.php");
date_default_timezone_set('Asia/Jakarta');
$nama = $_POST['nama'];
$kelas = $_POST['kelas'];
$pelanggaran = $_POST['pelanggaran'];
$date = date('Y-m-d');
$waktu = date('H:i:sa');

$input = $mysqli->query("INSERT INTO `pelanggaran`(`id_pelanggaran`, `nama`, `kelas`, `pelanggaran`, `tanggal`, `waktu`) VALUES 
('','$nama','$kelas','$pelanggaran','$date', '$waktu')");

switch ($pelanggaran) {
    case 'Kesiangan':
        $query = $mysqli->query("SELECT MAX(kesiangan) AS trs FROM tbl_pelanggaran");
        $data = $query->fetch_array();
        $tambahdata = $data['trs']+1;
        $tambah = $mysqli->query("UPDATE `tbl_pelanggaran` SET `kesiangan`='$tambahdata' WHERE 1");
        $datasiswa = $mysqli->query("SELECT `jumlah` FROM `siswa` WHERE NAMA = '$nama'");
        $tampil1 = $datasiswa->fetch_array();
        if ($tampil1['jumlah'] == '') {
            $tambah = $mysqli->query("UPDATE `siswa` SET `jumlah` = '1' WHERE NAMA = '$nama'");
        }else {
            $cari = $mysqli->query("SELECT MAX(jumlah) AS ksn FROM siswa WHERE NAMA = '$nama'");
            $datacari = $cari->fetch_array();
            $tambahdatacari = $datacari['ksn']+1;
            $tambahcari = $mysqli->query("UPDATE `siswa` SET `jumlah`='$tambahdatacari' WHERE `NAMA` = '$nama'");
        }
        break;
    case 'Skoder':
        $query = $mysqli->query("SELECT MAX(skoder) AS trs FROM tbl_pelanggaran");
        $data = $query->fetch_array();
        $tambahdata = $data['trs']+1;
        $tambah = $mysqli->query("UPDATE `tbl_pelanggaran` SET `skoder`='$tambahdata' WHERE 1");
        break;
    case 'Dasi':
        $query = $mysqli->query("SELECT MAX(dasi) AS trs FROM tbl_pelanggaran");
        $data = $query->fetch_array();
        $tambahdata = $data['trs']+1;
        $tambah = $mysqli->query("UPDATE `tbl_pelanggaran` SET `dasi`='$tambahdata' WHERE 1");
        break;
    case 'Sepatu':
        $query = $mysqli->query("SELECT MAX(sepatu) AS trs FROM tbl_pelanggaran");
        $data = $query->fetch_array();
        $tambahdata = $data['trs']+1;
        $tambah = $mysqli->query("UPDATE `tbl_pelanggaran` SET `sepatu`='$tambahdata' WHERE 1");
        break;
    case 'Kaos Kaki':
        $query = $mysqli->query("SELECT MAX(kaos_kaki) AS trs FROM tbl_pelanggaran");
        $data = $query->fetch_array();
        $tambahdata = $data['trs']+1;
        $tambah = $mysqli->query("UPDATE `tbl_pelanggaran` SET `kaos_kaki`='$tambahdata' WHERE 1");
        break;
    case 'Make Up':
        $query = $mysqli->query("SELECT MAX(make_up) AS trs FROM tbl_pelanggaran");
        $data = $query->fetch_array();
        $tambahdata = $data['trs']+1;
        $tambah = $mysqli->query("UPDATE `tbl_pelanggaran` SET `make_up`='$tambahdata' WHERE 1");
        break;
    case 'Pakaian':
        $query = $mysqli->query("SELECT MAX(pakian) AS trs FROM tbl_pelanggaran");
        $data = $query->fetch_array();
        $tambahdata = $data['trs']+1;
        $tambah = $mysqli->query("UPDATE `tbl_pelanggaran` SET `pakian`='$tambahdata' WHERE 1");
        break;
    case 'Sabuk':
        $query = $mysqli->query("SELECT MAX(sabuk) AS trs FROM tbl_pelanggaran");
        $data = $query->fetch_array();
        $tambahdata = $data['trs']+1;
        $tambah = $mysqli->query("UPDATE `tbl_pelanggaran` SET `sabuk`='$tambahdata' WHERE 1");
        break;
    

}
$pelajar = $mysqli->query("SELECT * FROM siswa");
$user = $pelajar->fetch_array();
if ($nama == $user['nama']){
    $melakukan = $mysqli->query("SELECT MAX(jumlah) AS jmlh FROM siswa");
    $dmelakukan = $melakukan->fetch_array();
    if ($dmelakukan['jmlh'] < 1) {
        $tambahd = $mysqli->query("INSERT INTO jumlah WHERE nama == '$nama'");
    }else {
        $tambahjlmh = $dmelakukan['jmlh']+1;
    $emelakukan = $mysqli->query("UPDATE siswa SET jumlah ='$tambahjmlh'");
    }
}
if ($input) {
    echo"berhasil";
} else {
    echo "gaga";
}