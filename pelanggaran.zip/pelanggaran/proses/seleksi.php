<?php
include "../cofig.php";
$nama = $_POST['nama'];
$kelas = $_POST['kelas'];

$seleksi = $mysqli->query("SELECT * FROM `siswa` WHERE `nama` = '$nama' AND `kelas` = '$kelas'");
// $qseleksi = $seleksi->num_rows;
if ($seleksi->num_rows > 0) {
    echo "berhasil";
} else {
    echo "gagal";
}